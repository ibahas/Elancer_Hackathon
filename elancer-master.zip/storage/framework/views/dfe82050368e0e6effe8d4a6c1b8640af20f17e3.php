<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\IbAHas\Downloads\Compressed\elancer-master\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>