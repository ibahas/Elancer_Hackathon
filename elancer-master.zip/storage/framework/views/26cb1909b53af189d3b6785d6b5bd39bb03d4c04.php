<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.dashborad'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="profile-container percentage-box profile queues">

        <div class="profile-row">
            <!-- ==Content home== -->
            <div class="tab-content dashboard_content ">

                <div class="tab-pane fade show active vh-100">
                    <h3><?php echo app('translator')->get('site.queues'); ?></h3>
                    <a href="<?php echo e(route('queues')); ?>"><?php echo app('translator')->get('site.all_queues'); ?></a>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col"><?php echo app('translator')->get('site.queue_user'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('site.queue_status'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('site.queue_no'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('site.action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $queues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($queue->user->name); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('changeStatus', $queue->id)); ?>" id="status_<?php echo e($queue->id); ?>" method="POST">
                                            <?php echo csrf_field(); ?>

                                            <select name="status" id="status" onchange="document.getElementById('status_<?php echo e($queue->id); ?>').submit()">
                                                <option value="open"><?php echo app('translator')->get('site.open'); ?></option>
                                                <option value="complet"><?php echo app('translator')->get('site.complet'); ?></option>
                                                <option value="uncompleted"><?php echo app('translator')->get('site.uncompleted'); ?></option>
                                            </select>
                                        </form>
                                    </td>
                                    <td><?php echo e($queue->no); ?></td>
                                    <td><?php echo e(title($queue->category)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('queue.edit', $queue)); ?>"
                                            class="btn btn-info bx bx-pen"><?php echo app('translator')->get('site.edit'); ?></a>
                                        <br>
                                        <form action="<?php echo e(route('queue.destroy', $queue)); ?>" method="POST"
                                            id="formDelete_<?php echo e($queue->id); ?>">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>

                                        </form>
                                        <button type="button" class="btn btn-danger bx bx-trash"
                                            onclick="document.getElementById('formDelete_<?php echo e($queue->id); ?>').submit()"><?php echo app('translator')->get('site.delete'); ?></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
    <div class="profile-container percentage-box profile clients">

        <div class="profile-row">
            <!-- ==Content home== -->
            <div class="tab-content dashboard_content">

                <div class="tab-pane fade show active vh-100">
                    <h3><?php echo app('translator')->get('site.clients'); ?></h3>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col"><?php echo app('translator')->get('site.name_user'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('site.email_user'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('site.action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($client->name); ?></td>
                                    <td><?php echo e($client->email); ?></td>
                                    <td>

                                        <form action="<?php echo e(route('client.destroy', $client)); ?>" method="POST"
                                            id="formDelet_e_<?php echo e($client->id); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>

                                        </form>
                                        <button type="button" class="btn btn-danger bx bx-trash"
                                            onclick="document.getElementById('formDelet_e_<?php echo e($client->id); ?>').submit()"><?php echo app('translator')->get('site.delete'); ?></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
    <div class="profile-container percentage-box profile categories">

        <div class="profile-row">
            <!-- ==Content home== -->
            <div class="tab-content dashboard_content">


                <div class="tab-pane fade show active vh-100">
                    <h3><?php echo app('translator')->get('site.categories'); ?></h3>
                    <a href="<?php echo e(route('service.create')); ?>"><?php echo app('translator')->get('site.new_cat'); ?></a>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col"><?php echo app('translator')->get('site.name'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('site.email'); ?></th>
                                <th scope="col"><?php echo app('translator')->get('site.action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                                    <td><?php echo e($category->title); ?></td>
                                    <td><?php echo e($category->title); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('service.edit', $category)); ?>"
                                            class="btn btn-info bx bx-pen"><?php echo app('translator')->get('site.edit'); ?></a>
                                        <br>
                                        <form action="<?php echo e(route('service.destroy', $category)); ?>" method="POST"
                                            id="formDelete__<?php echo e($category->id); ?>">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>

                                        </form>
                                        <button type="button" class="btn btn-danger bx bx-trash"
                                            onclick="document.getElementById('formDelete__<?php echo e($category->id); ?>').submit()"><?php echo app('translator')->get('site.delete'); ?></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>






    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.settings','data' => []]); ?>
<?php $component->withName('settings'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IbAHas\Downloads\Compressed\elancer-master\resources\views/dashboard.blade.php ENDPATH**/ ?>