<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.account_settings'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="profile-container percentage-box profile queue">

        <div class="profile-row">
            <!-- ==Content home== -->
            <div class="tab-content dashboard_content">
                <div class="tab-pane fade show active vh-100">
                    <h3><?php echo app('translator')->get('site.waiting_list_reservation'); ?> </h3>
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success">
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <div class="row">

                        <form method="post" action="<?php echo e(route('queue.store')); ?>" enctype="multipart/form-data"
                            class="col-6">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <p class="col-12">
                                    <label for="category_id"><?php echo app('translator')->get('site.title_cat'); ?> <span
                                            class="required">*</span></label>
                                    <select name="category_id" id="category_id" class="form-control">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo e(title($category)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </p>


                            </diV>
                            <button type="submit"
                                class="btn btn-primary btn-xl btn-block btn_login"><?php echo app('translator')->get('site.request'); ?></button>
                        </form>
                        <?php if($clientQueue): ?>
                            <div class="col-6">
                                <div class="alert alert-success">
                                    <?php
                                        echo trans('site.queue_no') . ' ' . $clientQueue['no'] . ' ' . trans('site.remaining_time') . ' ' . $var . ' ' . trans('site.minute\s');
                                        
                                    ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.settings','data' => []]); ?>
<?php $component->withName('settings'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IbAHas\Downloads\Compressed\elancer-master\resources\views/home.blade.php ENDPATH**/ ?>