<?php echo e($slot); ?>

<?php /**PATH C:\Users\IbAHas\Downloads\Compressed\elancer-master\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>