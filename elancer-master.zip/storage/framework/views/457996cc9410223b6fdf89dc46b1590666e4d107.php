<div class="profile-container percentage-box profile settings">

    <div class="profile-row">
        <!-- ==Content home== -->
        <div class="tab-content dashboard_content">
            <div class="tab-pane fade show active vh-100">
                <h3><?php echo app('translator')->get('site.settings'); ?> </h3>
                <form method="post" action="<?php echo e(route('client.updateProfile')); ?>" enctype="multipart/form-data"
                    autocomplete="off">

                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <p class="col-lg-6 col-md-6 invalid  ">
                            <label><?php echo app('translator')->get('site.name'); ?> <span class="required">*</span><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span
                                    class="error text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
                            <input type="text" required name="name"
                                class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(Auth::user()->name); ?>">
                        </p>


                        <p class="col-lg-6 col-md-6">
                            <label><?php echo app('translator')->get('site.email'); ?> <span class="required">*</span><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="error text-danger"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
                            <input type="text" name="email" required
                                class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                value="<?php echo e(Auth::user()->email); ?>">

                        </p>

                    </diV>
                    <button type="submit" class="btn btn-primary btn-xl btn-block btn_login"><?php echo app('translator')->get('site.save'); ?></button>


                </form>

            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\IbAHas\Downloads\Compressed\elancer-master\resources\views/components/settings.blade.php ENDPATH**/ ?>