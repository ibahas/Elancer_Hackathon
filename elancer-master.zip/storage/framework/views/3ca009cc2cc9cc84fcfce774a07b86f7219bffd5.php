<div class="form-group">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['id' => 'title','class' => 'form-control-lg','dataId' => $category->id,'name' => 'title','label' => ''.e(trans('site.title_cat')).'','value' => $category->title]]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'title','class' => 'form-control-lg','data-id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->id),'name' => 'title','label' => ''.e(trans('site.title_cat')).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->title)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</div>
<div class="form-group">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['id' => 'titleAr','class' => 'form-control-lg','dataId' => $category->id,'name' => 'titleAr','label' => ''.e(trans('site.title_cat_ar')).'','value' => $category->titleAr]]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'titleAr','class' => 'form-control-lg','data-id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->id),'name' => 'titleAr','label' => ''.e(trans('site.title_cat_ar')).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->titleAr)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</div>

<div class="form-group">
    <label for="description"><?php echo app('translator')->get('site.description_cat'); ?></label>
    <textarea id="description" name="description"
        class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('description', $category->description)); ?></textarea>
    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-danger"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <label for="descriptionAr"><?php echo app('translator')->get('site.description_cat_ar'); ?></label>
    <textarea id="descriptionAr" name="descriptionAr"
        class="form-control <?php $__errorArgs = ['descriptionAr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('descriptionAr', $category->descriptionAr)); ?></textarea>
    <?php $__errorArgs = ['descriptionAr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-danger"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<div class="form-group">
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.form.input','data' => ['id' => 'time','class' => 'form-control-lg','dataId' => $category->time,'name' => 'time','type' => 'number','label' => ''.e(trans('site.remaining_time')).'','value' => $category->time]]); ?>
<?php $component->withName('form.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'time','class' => 'form-control-lg','data-id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->time),'name' => 'time','type' => 'number','label' => ''.e(trans('site.remaining_time')).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($category->time)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
</div>
<div class="form-group">
    <button class="btn btn-primary"><?php echo app('translator')->get('site.save'); ?></button>
</div>
<?php /**PATH C:\Users\IbAHas\Downloads\Compressed\elancer-master\resources\views/categories/_form.blade.php ENDPATH**/ ?>