
<?php $__env->startSection('title'); ?>
    <?php echo app('translator')->get('site.dashborad'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="profile-container percentage-box profile categories">

        <div class="profile-row">
            <!-- ==Content home== -->
            <div class="tab-content dashboard_content">
                <div class="tab-pane fade show active vh-100" id="queues">
                    <h3><?php echo app('translator')->get('site.clients'); ?></h3>
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('site.queue_no'); ?></th>
                                <th><?php echo app('translator')->get('site.queue_status'); ?></th>
                                <th><?php echo app('translator')->get('site.queue_user'); ?></th>
                                <th><?php echo app('translator')->get('site.queue_cat'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $queues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $queue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($queue->status); ?></td>
                                    <td><?php echo e($queue->user->name); ?></td>
                                    <td><?php echo e(title($queue->category)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\IbAHas\Downloads\Compressed\elancer-master\resources\views/queues.blade.php ENDPATH**/ ?>